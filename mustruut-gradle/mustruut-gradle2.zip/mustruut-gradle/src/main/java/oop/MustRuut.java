package oop;

import javafx.application.Application;
import javafx.stage.Stage;

public class MustRuut extends Application {

    @Override
    public void start(Stage peaLava) throws Exception {
        peaLava.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
